# TRADING_PRECHECK_RUNBOOK

Validate receipts.
Diff against references.
Any failure is a correct stop.
